name             'test_helpers'
maintainer       'The authors'
maintainer_email 'me@here.mail'
license          'all'
description      'cookbook for unit tests etc of custom resources'
long_description 'cookbook for unit tests etc of custom resources'
version          '0.1.0'

depends 'monitored-cron'
