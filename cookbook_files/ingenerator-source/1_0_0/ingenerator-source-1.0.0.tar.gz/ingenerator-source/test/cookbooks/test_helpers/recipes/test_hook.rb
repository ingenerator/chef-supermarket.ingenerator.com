node.override['test']['hook']['release_path'] = this_release_path
