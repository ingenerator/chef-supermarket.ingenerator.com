# Xdebug attributes
# Only relevant if the `project.install_dev_tools` attribute is set

default['php']['xdebug']['version'] = '2.3.3'
