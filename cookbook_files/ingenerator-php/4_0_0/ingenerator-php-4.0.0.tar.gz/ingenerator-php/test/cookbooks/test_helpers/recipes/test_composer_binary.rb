composer_binary node['test']['path'] do
  action node['test']['action']
end
