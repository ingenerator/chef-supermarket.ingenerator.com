composer_dependencies node['test']['project_dir'] do
  run_as node['test']['run_as']
end
