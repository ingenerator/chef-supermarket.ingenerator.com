# Used for running spec tests of default attributes
