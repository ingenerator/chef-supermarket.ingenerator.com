#
# These attributes, which may be set in more than one cookbook, are intended to be set
# once at project level for a given role and control the behaviour of multiple recipes.
#
default['project']['install_dev_tools'] = false
